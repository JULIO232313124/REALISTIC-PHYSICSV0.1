-- =========================================================
-- REALISTIC BRUTAL PHYSICS - FS17
-- Target: Farming Simulator 17 / GIANTS Engine 7
-- Build: 0.1.0.0
--
-- V1 applies conservative multipliers while the base game
-- loads each wheel's XML physics data. This avoids changing
-- vehicle XML files and avoids rebuilding wheel shapes at runtime.
-- =========================================================

RBP_Physics = {}
RBP_Physics.name = "REALISTIC BRUTAL PHYSICS"
RBP_Physics.version = "0.1.0.0"
RBP_Physics.enabled = true
RBP_Physics.springScale = 1.04
RBP_Physics.dampingScale = 1.12
RBP_Physics.frictionScale = 0.97
RBP_Physics.brakeScale = 1.00
RBP_Physics.hookInstalled = false

local function rbpClamp(value, minimum, maximum)
    if value < minimum then return minimum end
    if value > maximum then return maximum end
    return value
end

local function rbpLoadConfig()
    if loadXMLFile == nil or getXMLBool == nil or getXMLFloat == nil then
        print("[RBP] XML functions unavailable; using built-in defaults.")
        return
    end

    local baseDir = g_currentModDirectory or ""
    local filename = baseDir .. "config/physics.xml"
    local xmlFile = loadXMLFile("RBP_PhysicsConfig", filename)

    if xmlFile == nil or xmlFile == 0 then
        print("[RBP] Config not found; using built-in defaults: " .. filename)
        return
    end

    local enabled = getXMLBool(xmlFile, "realisticBrutalPhysics#enabled")
    if enabled ~= nil then
        RBP_Physics.enabled = enabled
    end

    local spring = getXMLFloat(xmlFile, "realisticBrutalPhysics.wheels#springScale")
    local damping = getXMLFloat(xmlFile, "realisticBrutalPhysics.wheels#dampingScale")
    local friction = getXMLFloat(xmlFile, "realisticBrutalPhysics.wheels#frictionScale")
    local brake = getXMLFloat(xmlFile, "realisticBrutalPhysics.wheels#brakeScale")

    if spring ~= nil then RBP_Physics.springScale = rbpClamp(spring, 0.80, 1.25) end
    if damping ~= nil then RBP_Physics.dampingScale = rbpClamp(damping, 0.80, 1.35) end
    if friction ~= nil then RBP_Physics.frictionScale = rbpClamp(friction, 0.70, 1.20) end
    if brake ~= nil then RBP_Physics.brakeScale = rbpClamp(brake, 0.80, 1.20) end

    delete(xmlFile)
end

local function rbpApplyWheelTuning(vehicle, wheel)
    if not RBP_Physics.enabled or wheel == nil then
        return
    end

    -- Prevent accidental double scaling if a wheel table is revisited.
    if wheel.rbpPhysicsApplied then
        return
    end
    wheel.rbpPhysicsApplied = true

    if type(wheel.spring) == "number" and wheel.spring > 0 then
        wheel.spring = wheel.spring * RBP_Physics.springScale
    end

    local dampingFields = {
        "damperCompressionLowSpeed",
        "damperCompressionHighSpeed",
        "damperRelaxationLowSpeed",
        "damperRelaxationHighSpeed"
    }

    for _, fieldName in ipairs(dampingFields) do
        local value = wheel[fieldName]
        if type(value) == "number" and value > 0 then
            wheel[fieldName] = value * RBP_Physics.dampingScale
        end
    end

    if type(wheel.frictionScale) == "number" and wheel.frictionScale > 0 then
        wheel.frictionScale = wheel.frictionScale * RBP_Physics.frictionScale
    end

    if type(wheel.brakeFactor) == "number" and wheel.brakeFactor > 0 then
        wheel.brakeFactor = wheel.brakeFactor * RBP_Physics.brakeScale
    end

    if vehicle ~= nil and not vehicle.rbpPhysicsLogWritten then
        vehicle.rbpPhysicsLogWritten = true
        print(string.format(
            "[RBP] Physics profile applied to: %s | spring x%.2f | damping x%.2f | tire friction x%.2f",
            tostring(vehicle.configFileName or vehicle.typeName or "vehicle"),
            RBP_Physics.springScale,
            RBP_Physics.dampingScale,
            RBP_Physics.frictionScale
        ))
    end
end

local function rbpInstallHook()
    if RBP_Physics.hookInstalled then
        return
    end

    if Vehicle == nil or Vehicle.loadDynamicWheelDataFromXML == nil then
        print("[RBP] ERROR: Vehicle.loadDynamicWheelDataFromXML not found. Physics hook not installed.")
        return
    end

    if Utils == nil or Utils.appendedFunction == nil then
        print("[RBP] ERROR: Utils.appendedFunction not found. Physics hook not installed.")
        return
    end

    Vehicle.loadDynamicWheelDataFromXML = Utils.appendedFunction(
        Vehicle.loadDynamicWheelDataFromXML,
        function(vehicle, xmlFile, key, wheelnamei, wheel)
            rbpApplyWheelTuning(vehicle, wheel)
        end
    )

    RBP_Physics.hookInstalled = true
    print("[RBP] Wheel physics hook installed.")
end

rbpLoadConfig()
rbpInstallHook()

print("==================================================")
print(" " .. RBP_Physics.name .. " v" .. RBP_Physics.version)
print(" Enabled: " .. tostring(RBP_Physics.enabled))
print(" Spring scale: " .. tostring(RBP_Physics.springScale))
print(" Damping scale: " .. tostring(RBP_Physics.dampingScale))
print(" Tire friction scale: " .. tostring(RBP_Physics.frictionScale))
print(" Brake scale: " .. tostring(RBP_Physics.brakeScale))
print("==================================================")
