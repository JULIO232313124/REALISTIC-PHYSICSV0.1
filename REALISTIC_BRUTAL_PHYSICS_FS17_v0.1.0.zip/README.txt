REALISTIC BRUTAL PHYSICS FS17 - v0.1.0.0
Target: Farming Simulator 17, GIANTS Engine 7
Test target reported by user: FS17 1.2.0.0

INSTALLATION
1. Copy REALISTIC_BRUTAL_PHYSICS_FS17.zip into:
   Documents\My Games\FarmingSimulator2017\mods
2. Start FS17 and enable the mod in the mod selection screen.
3. Load a savegame and check log.txt for [RBP].

WHAT V0.1 DOES
- Hooks Vehicle.loadDynamicWheelDataFromXML, a documented FS17 Vehicle method.
- Scales loaded wheel spring, damper and tire friction values using small configurable multipliers.
- Does not edit any vehicle XML/I3D file.
- Does not change engine torque, vehicle mass, center of mass, steering geometry or brake force in this version.

DEFAULT PROFILE
- springScale: 1.04 (4% stiffer spring value)
- dampingScale: 1.12 (12% more damping)
- frictionScale: 0.97 (3% less tire friction scale)
- brakeScale: 1.00 (unchanged)

CONFIGURATION
Edit config/physics.xml. Set enabled="false" to disable adjustments.
Keep values moderate. The script clamps values to safe experimental ranges.

IMPORTANT LIMITATIONS
- This is an experimental global wheel-tuning prototype, not a validated real-world vehicle simulation.
- Vehicles that do not use the standard FS17 wheel-loading method may not be affected.
- Mod conflicts are possible if another script replaces Vehicle.loadDynamicWheelDataFromXML.
- Multiplayer is disabled in modDesc because the profile is not network-tested.
- Back up your savegame before testing.

TEST
After loading a save, inspect:
Documents\My Games\FarmingSimulator2017\log.txt
Expected messages include:
[RBP] Wheel physics hook installed.
[RBP] Physics profile applied to: ...

If no "Physics profile applied" message appears after entering a vehicle, send the [RBP] lines from log.txt.
